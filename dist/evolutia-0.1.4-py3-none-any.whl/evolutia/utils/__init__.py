"""
Utilidades para el generador de exámenes.
"""

