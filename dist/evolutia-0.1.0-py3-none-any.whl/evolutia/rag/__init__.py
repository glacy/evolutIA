"""
Sistema RAG (Retrieval-Augmented Generation) para generador de exámenes.
"""

__version__ = "1.0.0"

